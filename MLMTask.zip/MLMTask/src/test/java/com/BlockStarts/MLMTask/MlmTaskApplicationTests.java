package com.BlockStarts.MLMTask;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MlmTaskApplicationTests {

	@Test
	void contextLoads() {
	}

}
