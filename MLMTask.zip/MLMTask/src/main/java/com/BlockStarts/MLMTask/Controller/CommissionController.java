package com.BlockStarts.MLMTask.Controller;

import com.BlockStarts.MLMTask.Model.Commission;
import com.BlockStarts.MLMTask.Model.User;
import com.BlockStarts.MLMTask.Service.CommissionService;
import com.BlockStarts.MLMTask.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/commissions")
public class CommissionController {
    @Autowired
    private CommissionService commissionService;

    @Autowired
    private UserService userService;
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Commission>> getCommissionsForUser(@PathVariable Long userId) {
        User user = userService.getUserById(userId);
        List<Commission> commissions = commissionService.getCommissionsForUser(user);
        return new ResponseEntity<>(commissions, HttpStatus.OK);
    }
}