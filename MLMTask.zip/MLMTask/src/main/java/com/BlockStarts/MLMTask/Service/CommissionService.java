package com.BlockStarts.MLMTask.Service;

import com.BlockStarts.MLMTask.Model.Commission;
import com.BlockStarts.MLMTask.Model.User;
import com.BlockStarts.MLMTask.Repository.CommissionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CommissionService {
    @Autowired
    private CommissionRepository commissionRepository;

    private static final int MAX_LEVELS = 3;
    private static final double[] COMMISSION_PERCENTAGES = {10.0, 5.0, 2.5}; // Adjust percentages based on levels

        public List<Commission> getCommissionsForUser(User user) {
        return commissionRepository.findByUser(user);
    }

    public double calculateCommission(User user, double amount) {
        int referralLevel = getUserReferralLevel(user);
        double commissionPercentage = getCommissionPercentage(referralLevel);

        double commission = (commissionPercentage / 100.0) * amount;

        return commission;
    }

    private int getUserReferralLevel(User user) {
        return Math.min(getUserReferralLevel(user), MAX_LEVELS);
    }

    private double getCommissionPercentage(int referralLevel) {

        if (referralLevel > 0 && referralLevel <= COMMISSION_PERCENTAGES.length) {
            return COMMISSION_PERCENTAGES[referralLevel - 1];
        }
        return 0.0;
    }
}
