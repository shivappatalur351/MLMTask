package com.BlockStarts.MLMTask.Controller;

import com.BlockStarts.MLMTask.Service.ReferralService;
import com.BlockStarts.MLMTask.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/referrals")
public class ReferralController {
    @Autowired
    private ReferralService referralService;

    @Autowired
    private UserService userService;

    @PostMapping("/record")
    public ResponseEntity<String> recordReferral(
            @RequestParam Long referrerId, @RequestParam Long referredId) {
        referralService.recordReferral(userService.getUserById(referrerId), userService.getUserById(referredId));
        return new ResponseEntity<>("Referral recorded successfully", HttpStatus.OK);
    }
}
