package com.BlockStarts.MLMTask.Service;

import com.BlockStarts.MLMTask.Model.User;
import com.BlockStarts.MLMTask.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;

    public User registerUser(User user) throws Exception {

        if (userRepository.existsByUsername(user.getEmail())) {
            throw new Exception("Username is already taken");
        }

        User registeredUser = userRepository.save(user);

        return registeredUser;
    }

    public User getUserById(Long userId) {
        return userRepository.findById(userId).orElse(null);
    }

}