package com.BlockStarts.MLMTask.Repository;

import com.BlockStarts.MLMTask.Model.Referral;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReferralRepository extends JpaRepository<Referral, Long> {
    // Custom queries if needed
}
