package com.BlockStarts.MLMTask.Repository;

import com.BlockStarts.MLMTask.Model.Commission;
import com.BlockStarts.MLMTask.Model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CommissionRepository extends JpaRepository<Commission, Long> {
    List<Commission> findByUserId(Long userId);

    List<Commission> findByUser(User user);
}

