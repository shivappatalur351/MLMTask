package com.BlockStarts.MLMTask.Service;

import com.BlockStarts.MLMTask.Model.Referral;
import com.BlockStarts.MLMTask.Model.User;
import com.BlockStarts.MLMTask.Repository.ReferralRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ReferralService {
    @Autowired
    private ReferralRepository referralRepository;

    public void recordReferral(User referrer, User referred) {
        // Implement referral recording logic
        Referral referral = new Referral();
        referral.setReferrer(referrer);
        referral.setReferred(referred);
        referralRepository.save(referral);
    }
}
